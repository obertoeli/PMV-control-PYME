# ControlPYME — MVP interactivo

Este proyecto contiene una demostración interactiva del MVP de ControlPYME.

## Cómo publicarlo gratis con GitHub Pages

1. Entra en https://github.com/ e inicia sesión.
2. Pulsa **New repository**.
3. Nombre recomendado: `controlpyme-mvp`.
4. Déjalo como **Public**.
5. Crea el repositorio.
6. Pulsa **Add file > Upload files**.
7. Sube el archivo `index.html`.
8. Pulsa **Commit changes**.
9. Ve a **Settings > Pages**.
10. En **Build and deployment**, selecciona:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
11. Guarda.
12. GitHub generará una dirección similar a:
   `https://TU-USUARIO.github.io/controlpyme-mvp/`

Ese enlace es el que puedes enviar a tu profesora.

## Qué puede probar la profesora

- Cambiar entre la interfaz de **Jefe** y **Empleado**.
- Crear y asignar una tarea.
- Cambiar el estado de una tarea.
- Registrar un avance.
- Volver al panel del jefe para ver el cambio.
- Ver el concepto de permisos **VER / MODIFICAR**.
- Ver los módulos futuros de Finanzas y Jurídico.

## Alcance del MVP

Este MVP demuestra el flujo principal de la propuesta. No es todavía una aplicación con usuarios reales, base de datos o sincronización entre dispositivos.
